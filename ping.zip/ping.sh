#!/bin/bash
while [ 1 ] ; do sudo ping -c 3 google.com; done
